# Jarvis - AI Voice Assistant for Android

A fully functional Android AI assistant that controls your phone using voice commands and on-screen understanding, powered by GROQ API.

## Features

- **Wake Word Detection**: Activate with "Jarvis"
- **Continuous Voice Listening**: Natural conversation flow
- **Screen Understanding**: Reads and understands current UI state
- **Smart Action Execution**: Performs actions via Accessibility Service
- **GROQ AI Brain**: Fast reasoning and command interpretation
- **Task Memory**: Save and replay workflows
- **Safety Layer**: Prevents dangerous operations
- **Floating UI**: Minimal status indicator

## Capabilities

- Open apps
- Search Google/YouTube
- Click buttons and UI elements
- Type text
- Scroll and swipe
- Navigate (back/home)
- Send messages
- Read screen content
- Multi-step commands

## Setup

### 1. Prerequisites

- Android 8.0 (API 26) or higher
- GROQ API key ([Get one here](https://console.groq.com))
- Porcupine wake word access key ([Get one here](https://picovoice.ai))

### 2. Configuration

Edit `JarvisVoiceService.kt` and add your API keys:

```kotlin
val apiKey = "YOUR_GROQ_API_KEY_HERE"
```

Edit `WakeWordDetector.kt` for Porcupine:

```kotlin
val accessKey = "YOUR_PORCUPINE_ACCESS_KEY"
```

### 3. Build

```bash
./gradlew assembleDebug
```

### 4. Install

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 5. Permissions

1. Grant microphone permission
2. Enable overlay permission
3. **Enable Accessibility Service** (Settings → Accessibility → Jarvis)

## Usage

1. Open the Jarvis app
2. Tap "Start Jarvis"
3. Say "Jarvis" followed by your command
4. Examples:
   - "Jarvis, open Instagram"
   - "Jarvis, search best AI tools"
   - "Jarvis, scroll down"
   - "Jarvis, reply okay to this message"
   - "Jarvis, stop"

## Architecture

```
Voice Input → Speech-to-Text → Screen Capture → GROQ API → Action JSON → Accessibility Service → Execute
```

### Core Components

- **JarvisVoiceService**: Main orchestrator service
- **JarvisAccessibilityService**: UI interaction engine
- **VoiceManager**: Speech recognition and TTS
- **GroqBrain**: AI command processing
- **ActionExecutor**: Command execution
- **ScreenUnderstanding**: Context capture
- **SafetyValidator**: Command validation
- **TaskMemory**: Workflow storage

## Action Types

| Action | Description | Parameters |
|--------|-------------|------------|
| `click` | Click UI element | `target_text` or `x,y` |
| `type` | Type text | `text` |
| `swipe` | Swipe gesture | `start_x,start_y,end_x,end_y` |
| `scroll` | Scroll screen | - |
| `open_app` | Launch app | `app_name` |
| `back` | Press back | - |
| `home` | Go home | - |
| `search` | Google search | `text` |

## Safety Features

- Blocks dangerous commands (factory reset, delete all)
- Prevents unauthorized banking/payment actions
- Requires confirmation for destructive operations
- Emergency stop: "Jarvis, stop"

## Customization

### Add Custom App Mappings

Edit `ActionExecutor.kt`:

```kotlin
private fun getPackageNameForApp(appName: String): String {
    return when (appName.lowercase()) {
        "myapp" -> "com.example.myapp"
        // Add more...
    }
}
```

### Modify AI Behavior

Edit system prompt in `GroqBrain.kt`

## Troubleshooting

**Assistant not responding:**
- Check Accessibility Service is enabled
- Verify microphone permission
- Ensure GROQ API key is valid

**Can't click elements:**
- Accessibility Service must be enabled
- Some system UI may be restricted

**Wake word not working:**
- Verify Porcupine access key
- Check microphone permission

## Limitations

- Requires Android 8.0+
- Some system apps may be restricted
- Banking apps may block automation
- Screen capture requires user consent

## License

MIT License - Feel free to modify and distribute

## Contributing

Pull requests welcome! Please test thoroughly on real devices.

## Disclaimer

This is an educational project. Use responsibly and respect app terms of service. The developer is not responsible for misuse.
