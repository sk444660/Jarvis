# Quick Start Guide

## Project Structure

```
JarvisAssistant/
├── app/
│   ├── src/main/
│   │   ├── java/com/jarvis/assistant/
│   │   │   ├── MainActivity.kt                    # Main UI
│   │   │   ├── service/
│   │   │   │   ├── JarvisVoiceService.kt         # Main orchestrator
│   │   │   │   └── JarvisAccessibilityService.kt # UI automation
│   │   │   ├── engine/
│   │   │   │   ├── GroqBrain.kt                  # AI reasoning
│   │   │   │   ├── ActionExecutor.kt             # Command execution
│   │   │   │   ├── ScreenUnderstanding.kt        # Context capture
│   │   │   │   └── SafetyValidator.kt            # Safety checks
│   │   │   ├── voice/
│   │   │   │   ├── VoiceManager.kt               # Speech I/O
│   │   │   │   └── WakeWordDetector.kt           # "Jarvis" detection
│   │   │   ├── memory/
│   │   │   │   └── TaskMemory.kt                 # Workflow storage
│   │   │   ├── ui/
│   │   │   │   └── FloatingAssistantUI.kt        # Overlay UI
│   │   │   ├── api/
│   │   │   │   └── GroqApiService.kt             # GROQ integration
│   │   │   └── model/
│   │   │       └── ActionCommand.kt              # Data models
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml
│   │   │   │   └── floating_assistant.xml
│   │   │   ├── values/strings.xml
│   │   │   └── xml/accessibility_service_config.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Setup Steps

### 1. Add API Keys

**File: `app/src/main/java/com/jarvis/assistant/service/JarvisVoiceService.kt`**
```kotlin
val apiKey = "gsk_YOUR_GROQ_API_KEY_HERE"
```

Get GROQ API key: https://console.groq.com/keys

**Note:** Porcupine wake word requires a paid license. For testing, you can modify the code to skip wake word detection and activate on any speech.

### 2. Build the App

```bash
cd JarvisAssistant
./gradlew assembleDebug
```

### 3. Install on Device

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 4. Grant Permissions

1. Open Jarvis app
2. Grant microphone permission
3. Grant overlay permission
4. **Enable Accessibility Service:**
   - Settings → Accessibility → Downloaded Services → Jarvis
   - Toggle ON

### 5. Test

Say: "Jarvis, open Chrome"

## Key Features Implemented

✅ Voice recognition with continuous listening
✅ GROQ API integration for AI reasoning
✅ Accessibility Service for UI automation
✅ Screen context understanding
✅ Action execution (click, type, swipe, scroll, open apps)
✅ Safety validation layer
✅ Task memory system
✅ Floating overlay UI
✅ Text-to-speech responses

## Supported Commands

- "Jarvis, open [app name]"
- "Jarvis, search [query]"
- "Jarvis, click [button text]"
- "Jarvis, type [text]"
- "Jarvis, scroll down"
- "Jarvis, go back"
- "Jarvis, go home"
- "Jarvis, stop"

## Architecture Flow

```
User speaks "Jarvis, open Instagram"
    ↓
VoiceManager (Speech-to-Text)
    ↓
ScreenUnderstanding (Capture current UI state)
    ↓
SafetyValidator (Check if command is safe)
    ↓
GroqBrain (AI processes command + context → JSON action)
    ↓
ActionExecutor (Parse and execute action)
    ↓
JarvisAccessibilityService (Perform UI automation)
    ↓
VoiceManager (Speak confirmation)
```

## Customization

### Add More Apps

Edit `ActionExecutor.kt`:
```kotlin
"spotify" -> "com.spotify.music"
"twitter" -> "com.twitter.android"
```

### Modify AI Behavior

Edit system prompt in `GroqBrain.kt`

### Adjust Safety Rules

Edit `SafetyValidator.kt` to add/remove restricted keywords

## Troubleshooting

**Issue:** Wake word not working
**Solution:** Porcupine requires a paid license. For testing, modify `JarvisVoiceService.kt` to skip wake word and activate on any speech.

**Issue:** Can't click elements
**Solution:** Ensure Accessibility Service is enabled in Settings

**Issue:** No voice response
**Solution:** Check TTS is initialized and device volume is up

## Next Steps

- Add MediaProjection for screen capture OCR
- Implement ML Kit text recognition
- Add workflow recording/replay
- Create settings UI for API key configuration
- Add multi-language support
- Implement scheduled automations

## Files: 13 Kotlin files, 4 XML files, 4 config files
