#!/bin/bash
# Build script for Jarvis Assistant

echo "Building Jarvis Assistant APK..."

cd "$(dirname "$0")"

# Check for Gradle
if ! command -v ./gradlew &> /dev/null; then
    echo "Error: Gradle wrapper not found"
    echo "Please run this on a machine with Android SDK installed"
    exit 1
fi

# Build debug APK
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "APK location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "To install:"
    echo "  adb install app/build/outputs/apk/debug/app-debug.apk"
else
    echo "❌ Build failed"
    exit 1
fi
