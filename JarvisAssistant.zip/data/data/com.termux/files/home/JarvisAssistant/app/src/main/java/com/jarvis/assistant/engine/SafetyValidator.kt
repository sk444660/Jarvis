package com.jarvis.assistant.engine

class SafetyValidator {

    private val dangerousKeywords = listOf(
        "delete all",
        "factory reset",
        "uninstall",
        "payment",
        "transfer money",
        "send payment",
        "bank",
        "password",
        "credit card"
    )

    private val restrictedApps = listOf(
        "banking",
        "payment",
        "wallet",
        "paypal",
        "venmo"
    )

    fun isCommandSafe(command: String, context: ScreenContext): Boolean {
        val lowerCommand = command.lowercase()

        if (dangerousKeywords.any { lowerCommand.contains(it) }) {
            return false
        }

        if (restrictedApps.any { context.currentApp.lowercase().contains(it) }) {
            if (lowerCommand.contains("send") ||
                lowerCommand.contains("pay") ||
                lowerCommand.contains("transfer")) {
                return false
            }
        }

        return true
    }

    fun requiresConfirmation(command: String): Boolean {
        val confirmationKeywords = listOf(
            "delete",
            "remove",
            "uninstall",
            "clear data"
        )
        return confirmationKeywords.any { command.lowercase().contains(it) }
    }
}
