package com.jarvis.assistant.ui

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import com.jarvis.assistant.R

class FloatingAssistantUI(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var floatingView: View? = null
    private var isShowing = false

    fun show() {
        if (isShowing) return

        floatingView = LayoutInflater.from(context).inflate(R.layout.floating_assistant, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 20
            y = 100
        }

        windowManager.addView(floatingView, params)
        isShowing = true
    }

    fun updateState(state: AssistantState) {
        floatingView?.let { view ->
            val statusIcon = view.findViewById<ImageView>(R.id.statusIcon)
            val statusText = view.findViewById<TextView>(R.id.statusText)

            when (state) {
                AssistantState.IDLE -> {
                    statusText.text = "Ready"
                }
                AssistantState.LISTENING -> {
                    statusText.text = "Listening..."
                }
                AssistantState.PROCESSING -> {
                    statusText.text = "Processing..."
                }
                AssistantState.EXECUTING -> {
                    statusText.text = "Executing..."
                }
            }
        }
    }

    fun hide() {
        if (isShowing && floatingView != null) {
            windowManager.removeView(floatingView)
            floatingView = null
            isShowing = false
        }
    }
}

enum class AssistantState {
    IDLE, LISTENING, PROCESSING, EXECUTING
}
