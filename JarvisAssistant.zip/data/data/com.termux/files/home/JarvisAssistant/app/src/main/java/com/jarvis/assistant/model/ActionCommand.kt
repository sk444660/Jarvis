package com.jarvis.assistant.model

import com.google.gson.annotations.SerializedName

data class ActionCommand(
    val action: String,
    @SerializedName("target_text") val targetText: String? = null,
    val text: String? = null,
    @SerializedName("app_name") val appName: String? = null,
    val x: Float? = null,
    val y: Float? = null,
    @SerializedName("start_x") val startX: Float? = null,
    @SerializedName("start_y") val startY: Float? = null,
    @SerializedName("end_x") val endX: Float? = null,
    @SerializedName("end_y") val endY: Float? = null,
    val duration: Long? = null,
    val response: String? = null
)

object ActionType {
    const val CLICK = "click"
    const val TYPE = "type"
    const val SWIPE = "swipe"
    const val SCROLL = "scroll"
    const val OPEN_APP = "open_app"
    const val BACK = "back"
    const val HOME = "home"
    const val LONG_PRESS = "long_press"
    const val WAIT = "wait"
    const val SPEAK = "speak"
    const val SEARCH = "search"
}
