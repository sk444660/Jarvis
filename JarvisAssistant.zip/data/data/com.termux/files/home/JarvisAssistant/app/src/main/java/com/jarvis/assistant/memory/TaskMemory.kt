package com.jarvis.assistant.memory

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.jarvis.assistant.model.ActionCommand
import java.io.File

class TaskMemory(context: Context) {

    private val memoryFile = File(context.filesDir, "task_memory.json")
    private val gson = Gson()
    private val savedTasks = mutableMapOf<String, List<ActionCommand>>()

    init {
        loadMemory()
    }

    fun saveTask(name: String, actions: List<ActionCommand>) {
        savedTasks[name] = actions
        persistMemory()
    }

    fun getTask(name: String): List<ActionCommand>? {
        return savedTasks[name]
    }

    fun getAllTasks(): Map<String, List<ActionCommand>> {
        return savedTasks.toMap()
    }

    fun deleteTask(name: String) {
        savedTasks.remove(name)
        persistMemory()
    }

    private fun loadMemory() {
        if (memoryFile.exists()) {
            try {
                val json = memoryFile.readText()
                val type = object : TypeToken<Map<String, List<ActionCommand>>>() {}.type
                savedTasks.putAll(gson.fromJson(json, type))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun persistMemory() {
        try {
            val json = gson.toJson(savedTasks)
            memoryFile.writeText(json)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
