package com.jarvis.assistant.engine

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.jarvis.assistant.model.ActionCommand
import com.jarvis.assistant.model.ActionType
import com.jarvis.assistant.service.JarvisAccessibilityService
import kotlinx.coroutines.delay

class ActionExecutor(private val context: Context) {

    private val accessibilityService: JarvisAccessibilityService?
        get() = JarvisAccessibilityService.instance

    suspend fun execute(command: ActionCommand): ExecutionResult {
        val service = accessibilityService
            ?: return ExecutionResult(false, "Accessibility service not available")

        return try {
            when (command.action) {
                ActionType.CLICK -> executeClick(service, command)
                ActionType.TYPE -> executeType(service, command)
                ActionType.SWIPE -> executeSwipe(service, command)
                ActionType.SCROLL -> executeScroll(service, command)
                ActionType.OPEN_APP -> executeOpenApp(command)
                ActionType.BACK -> executeBack(service)
                ActionType.HOME -> executeHome(service)
                ActionType.WAIT -> executeWait(command)
                ActionType.SEARCH -> executeSearch(command)
                else -> ExecutionResult(false, "Unknown action: ${command.action}")
            }
        } catch (e: Exception) {
            ExecutionResult(false, "Error: ${e.message}")
        }
    }

    private suspend fun executeClick(service: JarvisAccessibilityService, command: ActionCommand): ExecutionResult {
        return if (command.targetText != null) {
            val node = service.findNodeByText(command.targetText)
            if (node != null) {
                val success = service.clickNode(node)
                ExecutionResult(success, if (success) "Clicked on ${command.targetText}" else "Failed to click")
            } else {
                ExecutionResult(false, "Could not find ${command.targetText}")
            }
        } else if (command.x != null && command.y != null) {
            val success = service.performClick(command.x, command.y)
            ExecutionResult(success, if (success) "Clicked at position" else "Failed to click")
        } else {
            ExecutionResult(false, "No target specified for click")
        }
    }

    private suspend fun executeType(service: JarvisAccessibilityService, command: ActionCommand): ExecutionResult {
        val text = command.text ?: return ExecutionResult(false, "No text to type")
        val success = service.typeText(text)
        return ExecutionResult(success, if (success) "Typed: $text" else "Failed to type")
    }

    private suspend fun executeSwipe(service: JarvisAccessibilityService, command: ActionCommand): ExecutionResult {
        val startX = command.startX ?: return ExecutionResult(false, "Missing swipe coordinates")
        val startY = command.startY ?: return ExecutionResult(false, "Missing swipe coordinates")
        val endX = command.endX ?: return ExecutionResult(false, "Missing swipe coordinates")
        val endY = command.endY ?: return ExecutionResult(false, "Missing swipe coordinates")
        val duration = command.duration ?: 300L

        val success = service.performSwipe(startX, startY, endX, endY, duration)
        return ExecutionResult(success, if (success) "Swiped" else "Failed to swipe")
    }

    private suspend fun executeScroll(service: JarvisAccessibilityService, command: ActionCommand): ExecutionResult {
        val displayMetrics = context.resources.displayMetrics
        val screenHeight = displayMetrics.heightPixels.toFloat()
        val screenWidth = displayMetrics.widthPixels.toFloat()

        val startY = screenHeight * 0.7f
        val endY = screenHeight * 0.3f
        val centerX = screenWidth / 2

        val success = service.performSwipe(centerX, startY, centerX, endY, 300)
        return ExecutionResult(success, if (success) "Scrolled" else "Failed to scroll")
    }

    private fun executeOpenApp(command: ActionCommand): ExecutionResult {
        val appName = command.appName ?: return ExecutionResult(false, "No app name specified")

        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(getPackageNameForApp(appName))

        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ExecutionResult(true, "Opened $appName")
        } else {
            ExecutionResult(false, "Could not find app: $appName")
        }
    }

    private fun executeBack(service: JarvisAccessibilityService): ExecutionResult {
        service.performBack()
        return ExecutionResult(true, "Pressed back")
    }

    private fun executeHome(service: JarvisAccessibilityService): ExecutionResult {
        service.performHome()
        return ExecutionResult(true, "Went home")
    }

    private suspend fun executeWait(command: ActionCommand): ExecutionResult {
        val duration = command.duration ?: 1000L
        delay(duration)
        return ExecutionResult(true, "Waited ${duration}ms")
    }

    private fun executeSearch(command: ActionCommand): ExecutionResult {
        val query = command.text ?: return ExecutionResult(false, "No search query")
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ExecutionResult(true, "Searching for: $query")
    }

    private fun getPackageNameForApp(appName: String): String {
        return when (appName.lowercase()) {
            "instagram" -> "com.instagram.android"
            "whatsapp" -> "com.whatsapp"
            "chrome" -> "com.android.chrome"
            "youtube" -> "com.google.android.youtube"
            "gmail" -> "com.google.android.gm"
            "maps" -> "com.google.android.apps.maps"
            "settings" -> "com.android.settings"
            else -> appName
        }
    }
}

data class ExecutionResult(
    val success: Boolean,
    val message: String
)
