package com.jarvis.assistant.service

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.R
import com.jarvis.assistant.engine.ActionExecutor
import com.jarvis.assistant.engine.GroqBrain
import com.jarvis.assistant.engine.ScreenContext
import com.jarvis.assistant.engine.ScreenUnderstanding
import com.jarvis.assistant.engine.SafetyValidator
import com.jarvis.assistant.voice.VoiceManager
import kotlinx.coroutines.*

class JarvisVoiceService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var voiceManager: VoiceManager
    private lateinit var groqBrain: GroqBrain
    private lateinit var actionExecutor: ActionExecutor
    private lateinit var screenUnderstanding: ScreenUnderstanding
    private lateinit var safetyValidator: SafetyValidator

    private var isActive = false

    override fun onCreate() {
        super.onCreate()

        val apiKey = "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"

        voiceManager = VoiceManager(this)
        groqBrain = GroqBrain(this, apiKey)
        actionExecutor = ActionExecutor(this)
        screenUnderstanding = ScreenUnderstanding(this)
        safetyValidator = SafetyValidator()

        voiceManager.initialize {
            startListening()
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification("Jarvis is ready"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun startListening() {
        serviceScope.launch {
            voiceManager.commands.collect { command ->
                handleVoiceCommand(command)
            }
        }
        voiceManager.startListening()
    }

    private suspend fun handleVoiceCommand(command: String) {
        if (command.contains("jarvis", ignoreCase = true) || isActive) {
            isActive = true
            updateNotification("Listening...")

            val screenContext = screenUnderstanding.captureContext()

            if (!safetyValidator.isCommandSafe(command, screenContext)) {
                voiceManager.speak("I cannot perform that action for safety reasons")
                isActive = false
                return
            }

            val actionCommand = groqBrain.processCommand(command, screenContext)

            if (actionCommand != null) {
                actionCommand.response?.let { voiceManager.speak(it) }

                val result = actionExecutor.execute(actionCommand)

                if (!result.success) {
                    voiceManager.speak("Sorry, I couldn't complete that action")
                }
            } else {
                voiceManager.speak("I didn't understand that command")
            }

            if (command.contains("stop", ignoreCase = true)) {
                isActive = false
                updateNotification("Jarvis is ready")
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Jarvis Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Voice assistant service"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val notification = createNotification(text)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.shutdown()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "jarvis_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
