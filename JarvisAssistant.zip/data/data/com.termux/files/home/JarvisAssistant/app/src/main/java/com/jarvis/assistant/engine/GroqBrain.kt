package com.jarvis.assistant.engine

import android.content.Context
import com.google.gson.Gson
import com.jarvis.assistant.api.ChatRequest
import com.jarvis.assistant.api.GroqApiService
import com.jarvis.assistant.api.Message
import com.jarvis.assistant.model.ActionCommand

class GroqBrain(context: Context, apiKey: String) {

    private val groqApi = GroqApiService.create(apiKey)
    private val gson = Gson()
    private val conversationHistory = mutableListOf<Message>()

    init {
        conversationHistory.add(Message(
            role = "system",
            content = SYSTEM_PROMPT
        ))
    }

    suspend fun processCommand(
        userCommand: String,
        screenContext: ScreenContext
    ): ActionCommand? {
        val contextPrompt = buildContextPrompt(userCommand, screenContext)

        conversationHistory.add(Message(role = "user", content = contextPrompt))

        return try {
            val response = groqApi.chat(ChatRequest(
                messages = conversationHistory,
                temperature = 0.3f,
                maxTokens = 512
            ))

            val assistantMessage = response.choices.firstOrNull()?.message
            if (assistantMessage != null) {
                conversationHistory.add(assistantMessage)
                parseActionCommand(assistantMessage.content)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun buildContextPrompt(command: String, context: ScreenContext): String {
        return """
User Command: "$command"

Current Screen Context:
- App: ${context.currentApp}
- Screen Text: ${context.screenText.take(500)}
- Available UI Elements: ${context.uiElements.joinToString(", ")}

Respond with a JSON action command to execute this request.
        """.trimIndent()
    }

    private fun parseActionCommand(response: String): ActionCommand? {
        return try {
            val jsonStart = response.indexOf('{')
            val jsonEnd = response.lastIndexOf('}')
            if (jsonStart != -1 && jsonEnd != -1) {
                val json = response.substring(jsonStart, jsonEnd + 1)
                gson.fromJson(json, ActionCommand::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun clearHistory() {
        conversationHistory.clear()
        conversationHistory.add(Message(role = "system", content = SYSTEM_PROMPT))
    }

    companion object {
        private const val SYSTEM_PROMPT = """You are Jarvis, an AI assistant that controls Android phones through voice commands.

Your job is to understand user commands and the current screen state, then respond with a JSON action command.

Available actions:
- click: Click on UI element by text or coordinates
- type: Type text into focused input
- swipe: Swipe gesture with start/end coordinates
- scroll: Scroll the screen
- open_app: Open an application
- back: Press back button
- home: Go to home screen
- search: Search on Google
- speak: Speak a response to the user
- wait: Wait for duration in milliseconds

Response format (JSON only):
{
  "action": "click",
  "target_text": "Search",
  "response": "Clicking search button"
}

or

{
  "action": "open_app",
  "app_name": "Instagram",
  "response": "Opening Instagram"
}

or

{
  "action": "type",
  "text": "Hello world",
  "response": "Typing your message"
}

Always include a "response" field with what you're doing so the user gets voice feedback.
Be concise and execute commands efficiently. Respond ONLY with valid JSON."""
    }
}

data class ScreenContext(
    val currentApp: String,
    val screenText: String,
    val uiElements: List<String>
)
