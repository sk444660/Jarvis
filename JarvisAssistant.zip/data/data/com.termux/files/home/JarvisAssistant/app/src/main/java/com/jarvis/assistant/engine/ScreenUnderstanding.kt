package com.jarvis.assistant.engine

import android.content.Context
import com.jarvis.assistant.service.JarvisAccessibilityService

class ScreenUnderstanding(private val context: Context) {

    fun captureContext(): ScreenContext {
        val accessibilityService = JarvisAccessibilityService.instance

        val currentApp = accessibilityService?.getCurrentAppPackage() ?: "unknown"
        val screenText = accessibilityService?.getScreenText() ?: ""
        val uiElements = extractUIElements(screenText)

        return ScreenContext(
            currentApp = getAppName(currentApp),
            screenText = screenText,
            uiElements = uiElements
        )
    }

    private fun extractUIElements(screenText: String): List<String> {
        return screenText
            .split(" ")
            .filter { it.length > 2 }
            .distinct()
            .take(20)
    }

    private fun getAppName(packageName: String): String {
        return when {
            packageName.contains("instagram") -> "Instagram"
            packageName.contains("whatsapp") -> "WhatsApp"
            packageName.contains("chrome") -> "Chrome"
            packageName.contains("youtube") -> "YouTube"
            packageName.contains("gmail") -> "Gmail"
            packageName.contains("launcher") -> "Home Screen"
            else -> packageName
        }
    }
}
