package com.jarvis.assistant.voice

import android.content.Context
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow

class WakeWordDetector(private val context: Context, private val accessKey: String) {

    private var porcupine: Porcupine? = null
    private val wakeWordChannel = Channel<Unit>(Channel.UNLIMITED)

    val wakeWordDetected: Flow<Unit> = wakeWordChannel.receiveAsFlow()

    fun start() {
        try {
            porcupine = Porcupine.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .build(context)
        } catch (e: PorcupineException) {
            e.printStackTrace()
        }
    }

    fun processAudioFrame(audioFrame: ShortArray): Boolean {
        return try {
            val keywordIndex = porcupine?.process(audioFrame) ?: -1
            if (keywordIndex >= 0) {
                wakeWordChannel.trySend(Unit)
                true
            } else {
                false
            }
        } catch (e: PorcupineException) {
            false
        }
    }

    fun stop() {
        porcupine?.delete()
        wakeWordChannel.close()
    }
}
