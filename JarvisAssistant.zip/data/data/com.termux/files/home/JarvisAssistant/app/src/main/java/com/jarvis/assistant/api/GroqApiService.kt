package com.jarvis.assistant.api

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface GroqApiService {

    @Headers("Content-Type: application/json")
    @POST("openai/v1/chat/completions")
    suspend fun chat(@Body request: ChatRequest): ChatResponse

    companion object {
        fun create(apiKey: String): GroqApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://api.groq.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(okhttp3.OkHttpClient.Builder()
                    .addInterceptor { chain ->
                        val request = chain.request().newBuilder()
                            .addHeader("Authorization", "Bearer $apiKey")
                            .build()
                        chain.proceed(request)
                    }
                    .build())
                .build()

            return retrofit.create(GroqApiService::class.java)
        }
    }
}

data class ChatRequest(
    val model: String = "llama-3.3-70b-versatile",
    val messages: List<Message>,
    val temperature: Float = 0.7,
    @SerializedName("max_tokens") val maxTokens: Int = 1024
)

data class Message(
    val role: String,
    val content: String
)

data class ChatResponse(
    val choices: List<Choice>
)

data class Choice(
    val message: Message
)
