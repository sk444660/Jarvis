# Build Instructions

## Your GROQ API key has been added ✅

The API key is configured in `JarvisVoiceService.kt`

## Building the APK

Since Termux doesn't have Android SDK, you need to build on a computer with Android Studio:

### Option 1: Android Studio (Easiest)
1. Copy the `JarvisAssistant` folder to your computer
2. Open Android Studio → Open Project → Select `JarvisAssistant`
3. Click Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK will be in `app/build/outputs/apk/debug/app-debug.apk`

### Option 2: Command Line
```bash
cd JarvisAssistant
./gradlew assembleDebug
```

### Option 3: GitHub Actions (Automated)
Create `.github/workflows/build.yml`:
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
          distribution: 'temurin'
      - name: Build APK
        run: |
          chmod +x gradlew
          ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

## Installing

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Next Steps After Install

1. Open Jarvis app
2. Grant microphone permission
3. Grant overlay permission  
4. **Enable Accessibility Service**: Settings → Accessibility → Jarvis → Toggle ON
5. Tap "Start Jarvis"
6. Say: "Jarvis, open Chrome"

## Project is ready to build on a machine with Android SDK!
